
/**
 * 
 * 
 * Navigation Settings  Function
 * 
 * Link  <a href=""></a>
 * Heading <h1>
 * Line Brak <br>
 * 
 * 
 */
function navigation_fixed_top_2(url_s,a,b,myClass,store,r){

    var conndition_11 = screen.width;
    
    navigation_1n = store[0][0];// folder name request 1
    navigation_1n_css = store[1][0];
    
    navigation_2n = store[0][1];
    navigation_2n_css = store[1][1];
    
    navigation_2n_css_2 = store[2][0];
    
    
    
    
    
    opration_1 = `nav_js_j('.${a}','.${b}','none');`;	
    
    var output_nav = ``;
    
    
    
    
    output_nav += `<div class="anker-sidebar a-animate-left_1 anker-nav ${a}" ><br>`;
    
    render_get_0 = r.length;
    render_get_1 = render_get_0-1;
    
    
    
    if(navigation_1n==""){
    
    document.title = r[0][1];
    
    output_nav += `
    <style>.n-home-n${navigation_1n_css}</style>
    `; 
    
    }else{
    
    
    
    }
    
    
    
    
    
    
    
    
    
    
    for(i=0; i<=render_get_1; i++){ 
    
    
    
    
    
    
    data_not_sp_1 = r[i][1];
    
    data_not_sp_2 = r[i][3];
    
    class_sel = data_not_sp_1;
    
    class_sel_2 = data_not_sp_2;
    
    
    
    if(r[i][4]==""){
    icon_br = ``;
    }else{
    icon_br = `<i class="fa ${r[i][4]}"></i>&nbsp;`;
    }
    
    
    
    
    /**
    * 
    * Navigation
    * 
    */
    if(r[i][2]=='nav'){
    
    if(r[i][0]=="home"){
    
    // Home Start   
    
    output_nav += `
    <a class="anker-link n-${class_sel_2}-n" href="${url_s}">${icon_br} ${r[i][1]}</a>
    `;
    
    // Home End 
    
    }else{  
    
    if(r[i][0]==""){
    
    if(class_sel_2==navigation_1n){
    
    
    //Nav Group not function Start
    
    output_nav += `
    <a class="anker-link n-${class_sel_2}-n" >${icon_br} ${r[i][1]} <span class="a-right">-&nbsp</span></a>
    <style>.n-${class_sel_2}-n${navigation_1n_css}</style>
    `;
    
    //Nav Group not function End
    
    
    }else{
    
    
    //Nav Group function Start   
    
    output_nav += `
    <a class="anker-link n-${class_sel_2}-n" onclick="subnav_active('${class_sel_2}');">${icon_br} ${r[i][1]} <span class="a-right">+&nbsp</span></a>
    `;
    
    //Nav Group function End 
    
    }
    
    
    }else{
    
    
    // Single Nav Start
    
    output_nav += `
    <a class="anker-link n-${class_sel_2}-n" href="${url_s}${r[i][0]}">${icon_br} ${r[i][1]}</a>
    `;
    
    if(class_sel_2==navigation_1n){
    
    document.title = r[i][1];
    
    output_nav += `
    <style>.n-${class_sel_2}-n${navigation_1n_css}</style>
    `;
    
    }else{
    
    
    
    }
    
    // Single Nav End
    
    }
    
    }
    
    }
    
    
    /**
    * 
    * Sub-Navigation
    * 
    */
    if(r[i][2]=='subnav'){
    
    
    //  output_nav += `
    //  <div class="${class_sel_2}">
    //  <a class="anker-link ${class_sel} ${r[i][0]}" href="${url_s}${class_sel_2}/${r[i][0]}">${icon_br}${r[i][1]}</a>
    //  </div>
    //  <style>.${class_sel_2}${navigation_2n_css_2}</style>
    //  `;
    
    /* Copy here
    output_nav += `
    <div class="${class_sel_2} box-nav-666">
    <a class="anker-link ${r[i][0]}" href="${url_s}/${r[i][0]}/${class_sel_2}">${icon_br}${r[i][1]}</a>
    </div>
    <style>.${class_sel_2}${navigation_2n_css_2}</style>
    `;
    */
    
    output_nav += `
    <div class="${class_sel_2} box-nav-666">
    <a class="anker-link list_1000 ${r[i][0]}" href="${url_s}/${class_sel_2}/${r[i][0]}">${icon_br}  ${r[i][1]}</a>
    </div>
    <style>.${class_sel_2}${navigation_2n_css_2}</style>
    `;
    
    if(class_sel_2==navigation_1n){
    
    output_nav += `
    <style>
    .${class_sel_2}{display:block;}
    
    </style>
    `;
    
    if(r[i][0]==navigation_2n){
    
    document.title = r[i][1];
    
    output_nav += `
    <style>
    .${r[i][0]}${navigation_2n_css}
    </style>
    `;
    
    }else{
    
    }
    
    }else{
    
    output_nav += `
    <style>
    .${class_sel_2}{display:none;}
    </style>
    `;  
    
    }
    
    
    
    }
    
    
    
    
    
    
    
    if(r[i][2]=='link'){
    
    output_nav += `<a class="anker-link ${class_sel}" href="${url_s}${r[i][0]}">${r[i][1]}</a>`;
    
    }
    
    
    
    
    
    
    
    
    
    
    if(r[i][2]=='heading'){
    
    output_nav += `
    
    <div class="${class_sel_2}">
    <span class="anker-heading ${class_sel_2}">${r[i][1]}</span>
    </div>
    <style>
    .${class_sel_2}{ display:none; }
    .${class_sel_2}${navigation_2n_css_2}
    </style>
    
    `;    
    
    if(class_sel_2==navigation_1n){
    
    
    
    }else{
    
    output_nav += `
    <style>
    .${class_sel_2}{display:block;}
    </style>
    `;
    
    } 
    
    
    }
    
    
    
    
    if(r[i][2]=='br'){
    
    output_nav += `
    
    <div class="${class_sel_2}">
    <br>
    </div>
    
    <style>
    .${class_sel_2}{ display:none; }
    .${class_sel_2}${navigation_2n_css_2}
    </style>
    
    `;    
    
    if(class_sel_2==navigation_1n){
    
    
    
    }else{
    
    output_nav += `
    <style>
    .${class_sel_2}{display:block;}
    </style>
    `;
    
    } 
    
    
    }
    
    
    
    
    
    
    
    if(conndition_11<=991){
    
    my_cont_fun = opration_1;
    
    }else{
    
    my_cont_fun = "";
    
    }
    
    
    
    
    if(r[i][2]=='button'){
    
    option_2 = `document.querySelector('${r[i][0]}').style.display='block', ${opration_1}";`;
    
    output_nav += `<a class="anker-link ${class_sel}" onclick="${my_cont_fun}">${icon_br}  ${r[i][1]}</a>`;
    
    }
    
    
    
/* ---------------[ New / 2023 - 02 - 16 / link1 / Start ]----------------------- */ 

/*

Url ${url_s}  http:localhost:8500

If name : ${r[i][2]}

name : ${r[i][1]}

Url Route name: ${r[i][0]}

one link color select css : ${navigation_1n_css}


*/

if(r[i][2]=='link1'){

if(r[i][0]==navigation_1n){

output_nav_ghe453h3h = `<style>.b_${r[i][0]}_b${navigation_1n_css}</style>`;

}else{

output_nav_ghe453h3h = ``;

}


output_nav += `<a class="anker-link b_${r[i][0]}_b" href="${url_s}/${r[i][0]}"> ${icon_br}  ${r[i][1]} </a> ${output_nav_ghe453h3h}`;


/*

navigation_1n = store[0][0];// folder name request 1
navigation_1n_css = store[1][0]; // folder name request 2

navigation_2n = store[0][1];
navigation_2n_css = store[1][1];

navigation_2n_css_2 = store[2][0];
*/

}



/* ---------------[ New / 2023 - 02 - 16 / link1 / End ]----------------------- */  
    
    
    
    
    
    if(r[i][2]=='btn'){
    
    output_nav += `<a class="anker-link b_${r[i][0]}_b" onclick="route('${r[i][0]}'), ${my_cont_fun}">${icon_br}  ${r[i][1]}</a>`;
    
    }
    
    
    
    
    if(r[i][2]=='function'){
    
    
    
    output_nav += `<a class="anker-link b_${r[i][0]}_b" onclick="${r[i][0]} ">${icon_br}  ${r[i][1]}</a>`;
    
    }
    
    
    if(r[i][2]=='router'){
    
    
    
    output_nav += `<a class="anker-link b_${r[i][0]}_b" onclick="${r[i][0]} ${my_cont_fun}">${icon_br}  ${r[i][1]}</a>`;
    
    }
    
    
    
    
    
    
    if(r[i][2]=='image'){
    
    output_nav += `
    <center>
    <a  href="${r[i][0]}">
    <img src="${r[i][1]}" alt="nastech.js.php" class="nastech_image_profile " />
    </a>
    </center>
    `;
    
    }
    
    
    
    
    
    }
    //
    
    output_nav += `<br><br><br><br></div>`;
    
    output_nav += `<div class="anker-overlay anker-show ${b}" onclick="${opration_1}"></div>`;
    
    document.querySelector(myClass).innerHTML = output_nav;
    
    }
    
    /**
    * 
    * Navigation On OFF  Function
    * Display Block/None
    * 
    */
    
    function nav_js_j(a,b,c){ 
    document.querySelector(a).style.display = c;
    document.querySelector(b).style.display = c;
    }
    
    function subnav_active(a){
    $(`.${a}`).fadeToggle();
    }
    
    
    
    
    
    
    
    //////////////////////////////////////////////////
    //                   Form Box
    //////////////////////////////////////////////////
    
    function box_forms(div_id,css_classes,css_btn,html_tages,css_tags,display_class){
    
    var output = ``;
    
    output += ``;
    
    
    output += `
    
    <!----------------------box form Html--------------------->
    <div id="${div_id}" class="a-modal" style="z-index:200;">
    <div class="a-modal-content ${css_classes}" ${css_tags}>
    <div class="a-container">
    <button onclick="active_btn('${div_id}','off');" class="${css_btn}">&times;</button>
    <br>
    ${html_tages}
    </div>
    <br><br>
    </div>
    <br><br>
    </div>
    <!--------------------box form Html------------------------------->
    
    `;
    
    
    
    
    output += ``;
    
    $(display_class).html(output);
    
    
    }
    
    
    function active_btn(div_id,active){
    
    if(active=="on"){
    document.getElementById(div_id).style.display='block';
    }else{
    document.getElementById(div_id).style.display='none';
    }
    
    }
    
    
    
    function Error_Msg(Class_OR_ID,Value,Time_set){
    
    $(Class_OR_ID).fadeIn();
    
    $(Class_OR_ID).html(Value);
    
    setTimeout(function(){ $(Class_OR_ID).fadeOut(); },Time_set); 
     
    }
    
    
    function javascript_html(class_or_id,div_123){
    
        document.querySelector(class_or_id).innerHTML = div_123;
        
    }
    
    function javascript_html_copy(class_or_id,div_123){
    
        document.querySelector(class_or_id).innerHTML += div_123;
    
    }