var error_list = [

    `<div class="a-padding a-orange">Please enter email & password !! <span class="ty"></span></div>`,
    `<div class="a-padding a-orange">password 8 character required !! <span class="ty"></span></div>`,
    `<div class="a-padding a-grey">Email is not valid!! <span class="ty"></span></div>`,
    
    `<div class="a-padding a-deep-orange">Your Email, Password is not valid!! <span class="ty"></span></div>`,
    `<div class="a-padding a-red">Email is not valid!! <span class="ty"></span></div>`,
    `<div class="a-padding a-orange">password 8 character required !! <span class="ty"></span></div>`,
    `<div class="a-padding a-grey">Email & Password is not valid!! <span class="ty"></span></div>`,
    `<div class="a-padding a-green">You are Login... <span class="ty"></span></div>`,
    `<div class="a-padding a-black">You are Email & Password is not Error... <span class="ty"></span></div>`
        
    
    ];


    
    reload_3 = () => {

window.open(document.URL,"_self");
window.open(document.URL,"_self");
window.open(document.URL,"_self");

    }