module.exports = function(app,path_001,db_connection)
{


require("../controllers/home.js")(app,path_001,db_connection)
require("../controllers/about.js")(app,path_001,db_connection)
require("../controllers/contact.js")(app,path_001,db_connection)
require("../controllers/blog.js")(app,path_001,db_connection)

require("../controllers/test.js")(app,path_001)
require("../controllers/error.js")(app,path_001)


}