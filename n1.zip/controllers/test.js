module.exports = function(app,path_001)
{


app.get("/test",function(req,res){


    res.render(`${path_001}/views/test`)


})

app.get("/test/:id",function(req,res){


    res.render(`${path_001}/views/test`)


})


}