module.exports = function(app,path_001,db)
{


app.get("/blog",function(req,res){


var sql = "SELECT * FROM customer ORDER BY id DESC"

db.query(sql,function(error,result){

if(error) console.log(error)

res.render(`${path_001}/views/blog`,{customer:result})

})


}).get("/blog-delete/:id",function(req,res){


var idno = req.params.id

var sql = `delete from customer where id=${idno}`

db.query(sql,function(error,result){

if(error) console.log(error)

res.redirect(`/blog?delete=${idno}`)

})



})




}