module.exports = function(app,path_001)
{


app.get("/",function(req,res){


    res.render(`${path_001}/views/home`)


})




}