module.exports = function(app,path)
{


app.get("*",function(req,res){


    res.render(`${path}/views/error`)


})

}