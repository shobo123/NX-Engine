module.exports = function(app,path_001,db)
{


app.get("/contact",function(req,res){


    res.render(`${path_001}/views/contact`)


})


app.post("/contact-send",function(req,res){

    var name = req.body.name
    var email = req.body.email
    var address = req.body.address

    var sql = "INSERT INTO customer (name,email) VALUES ?"

    var values = [
    [name,email]
    ]
    
    db.query(sql,[values],function(error,result){
    
    if(error) console.log(error)
    
    res.redirect(`/contact`)
    
    })

    //console.log(name,email,address)
    


})

}