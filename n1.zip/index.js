// .Env
require('dotenv').config()

// Express.js
const express = require('express')

const app = express()

// Port
var port = process.env.PORT_DEFINE

// Path
var path = __dirname


// Ejs Template Engine
app.set(`view engine`, `ejs`)


//Static Files
app.use(express.static("public"))

// Form body
var bodyParser = require("body-Parser")
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended:true }))


// Database Connection
var db = require('./database/database.js')


// Routes
require("./routers/web.js")(app,path,db)


// Cmd Message Show
app.listen(port, () => {
console.log(`Server listening at http://localhost:${port}`)
})