
var mysql = require('mysql')

var con = mysql.createConnection({
  host: process.env.DATABASE_HOST,
  user: process.env.DATABASE_USER_NAME,
  password: process.env.DATABASE_PASSWORD,
  database: process.env.DATABASE_NAME,
})

con.connect(function(err) {
  if (err) throw err;
  //console.log("Connected!");
})

module.exports = con

/*
var mysql = require("mysql")

config = {
  connectionLimit: 50,
  host: "localhost",
  port: "3306",
  user: "root",
  password: "",
  database: "example_company",
};

var connection = mysql.createPool(config)

module.exports = connection
*/